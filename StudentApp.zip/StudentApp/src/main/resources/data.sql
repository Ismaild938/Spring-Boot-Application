insert into Student
values(10001,'Isma', 'D','John', 'Jessy','10th');

insert into Address
values(10002,'EC1', 'Bangalore','Karnataka');